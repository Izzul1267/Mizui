let handler = async (m) => {
m.reply(m.chat)
}
handler.command = ['cekid']

export default handler