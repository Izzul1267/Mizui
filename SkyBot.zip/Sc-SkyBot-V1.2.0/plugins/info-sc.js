/* 
* Mau Ngapain ?
* Mau Nge Ubah ?
* Ga Boleh Wk
* Minimal Jangan Ubah Lah Cape
*/
const _0x4e21b1 = _0x4eaa;
(function (_0x213b32, _0x54d8a2) {
    const _0x57babb = _0x4eaa, _0x3dbfdc = _0x213b32();
    while (!![]) {
        try {
            const _0x1a15d9 = -parseInt(_0x57babb(0x21e)) / (-0x236 + -0x21e7 + 0x120f * 0x2) + parseInt(_0x57babb(0x223)) / (-0x49d * -0x1 + -0x318 * -0xb + -0x26a3) + parseInt(_0x57babb(0x1f7)) / (0x205d + -0x1fbb + -0x35 * 0x3) * (parseInt(_0x57babb(0x200)) / (-0x105f + -0x1 * 0x232f + 0x75e * 0x7)) + -parseInt(_0x57babb(0x209)) / (-0x1a7d + -0x1647 * -0x1 + 0x43b) + parseInt(_0x57babb(0x210)) / (-0x493 * 0x1 + 0xe74 + -0x9db) + -parseInt(_0x57babb(0x203)) / (0x2160 + -0xa3e + -0x171b) + parseInt(_0x57babb(0x1f6)) / (0x10fd + 0x5 * -0x51b + -0x892 * -0x1);
            if (_0x1a15d9 === _0x54d8a2)
                break;
            else
                _0x3dbfdc['push'](_0x3dbfdc['shift']());
        } catch (_0x2e52f9) {
            _0x3dbfdc['push'](_0x3dbfdc['shift']());
        }
    }
}(_0x38ce, -0x2f5ab + -0x4190 + -0xe * -0x12044));
import _0x4b25bc from 'node-fetch';
let handler = async (_0x566b28, {
    conn: _0x335669,
    usedPrefix: _0x45e3f5
}) => {
    const _0x10375f = _0x4eaa, _0x283db5 = {
            'JEdUp': function (_0x232f19, _0x345f7b) {
                return _0x232f19 + _0x345f7b;
            },
            'pAjOU': _0x10375f(0x1fd) + 't',
            'jVfEC': _0x10375f(0x221),
            'SJdSm': _0x10375f(0x216),
            'hlISY': _0x10375f(0x202),
            'EQkxP': _0x10375f(0x1f1),
            'KfyeI': function (_0x486845, _0x479b87) {
                return _0x486845(_0x479b87);
            },
            'vVQsl': _0x10375f(0x1fd) + _0x10375f(0x213)
        };
    let _0x32ed56 = fla[_0x10375f(0x1f9)](), _0x4849db = _0x283db5[_0x10375f(0x1f4)](_0x32ed56, _0x283db5[_0x10375f(0x204)]), _0xd90679 = await _0x335669[_0x10375f(0x218)](_0x566b28[_0x10375f(0x20b)]), _0x41ad64 = _0x10375f(0x205) + _0xd90679 + '\x20' + ucapan + (_0x10375f(0x1f0) + _0x10375f(0x20f) + _0x10375f(0x21b) + _0x10375f(0x1ff) + _0x10375f(0x222) + _0x10375f(0x219) + _0x10375f(0x220) + _0x10375f(0x1ee) + _0x10375f(0x21d) + _0x10375f(0x211) + _0x10375f(0x21c) + _0x10375f(0x1fb) + _0x10375f(0x1ef) + _0x10375f(0x1ed) + _0x10375f(0x212) + _0x10375f(0x1fe) + _0x10375f(0x206) + _0x10375f(0x1f5) + _0x10375f(0x224) + _0x10375f(0x207) + _0x10375f(0x1fa) + _0x10375f(0x1fc) + _0x10375f(0x21f));
    await _0x335669[_0x10375f(0x21a) + _0x10375f(0x20a)](_0x566b28[_0x10375f(0x201)], _0x41ad64, author, _0x283db5[_0x10375f(0x225)], _0x283db5[_0x10375f(0x1f4)](_0x45e3f5, _0x283db5[_0x10375f(0x214)]), fkontak, {
        'contextInfo': {
            'forwardingScore': fsizedoc,
            'externalAdReply': {
                'body': _0x283db5[_0x10375f(0x20c)],
                'containsAutoReply': !![],
                'mediaType': 0x1,
                'mediaUrl': hwaifu[_0x10375f(0x1f9)](),
                'renderLargerThumbnail': !![],
                'showAdAttribution': !![],
                'sourceId': _0x283db5[_0x10375f(0x20c)],
                'sourceType': _0x283db5[_0x10375f(0x1f3)],
                'previewType': _0x283db5[_0x10375f(0x1f3)],
                'sourceUrl': sgc,
                'thumbnail': await (await _0x283db5[_0x10375f(0x1f2)](_0x4b25bc, _0x4849db))[_0x10375f(0x217)](),
                'thumbnailUrl': sgc,
                'title': _0x283db5[_0x10375f(0x1f8)]
            }
        }
    });
};
handler[_0x4e21b1(0x215)] = ['sc'], handler[_0x4e21b1(0x20d)] = [_0x4e21b1(0x208)], handler[_0x4e21b1(0x20e)] = /^(sc|script)$/i;
function _0x4eaa(_0xaa4806, _0x5595a2) {
    const _0x104c48 = _0x38ce();
    return _0x4eaa = function (_0x329f5f, _0x1aa4cd) {
        _0x329f5f = _0x329f5f - (0xed * 0x12 + 0x2 * -0x137 + -0x17 * 0x89);
        let _0x2c7f92 = _0x104c48[_0x329f5f];
        return _0x2c7f92;
    }, _0x4eaa(_0xaa4806, _0x5595a2);
}
export default handler;
function _0x38ce() {
    const _0x35b4b0 = [
        'sendButton',
        'ck\x20Link\x20Di',
        'gan\x20Lupa\x20S',
        '_85Kttqq6u',
        '131278qsevmE',
        '..\x0a',
        'com/channe',
        'Owner',
        'k\x20:\x20https:',
        '2826632VsKIQI',
        '.ly/3VzmBU',
        'jVfEC',
        'bih\x20Lanjut',
        'l/UCbLk8Zd',
        'Mau\x20Tau\x20Le',
        '\x0a\x0aLagi\x20Car',
        'PDF',
        'KfyeI',
        'EQkxP',
        'JEdUp',
        'ttps://bit',
        '6255232PyWRPJ',
        '27VPohoW',
        'vVQsl',
        'getRandom',
        'ick\x20Button',
        'ubscribe\x0a\x0a',
        '\x20Di\x20Bawah.',
        'Info\x20Scrip',
        '\x20Link\x20Di\x20B',
        '\x20Bawah\x0aLin',
        '72232wtFyNl',
        'chat',
        '©\x20𝐒𝐤𝐲𝐁𝗼𝐭',
        '6852685QNjKas',
        'pAjOU',
        'Hai\x20',
        'awah\x20!\x20]\x0ah',
        'Y\x0a\x0aAtau\x20Cl',
        'info',
        '7597030Pefhrj',
        'Doc',
        'sender',
        'hlISY',
        'tags',
        'command',
        'i\x20Sc\x20?\x0aCli',
        '6565764KSZwFE',
        'IDqF5w\x0aJan',
        '\x20?\x0a[\x20Click',
        't\x20SkyBot',
        'SJdSm',
        'help',
        'owner',
        'buffer',
        'getName',
        '//youtube.'
    ];
    _0x38ce = function () {
        return _0x35b4b0;
    };
    return _0x38ce();
}