let handler = async (m) => {
m.reply(wait)
}
handler.command = ['gctes']

handler.group = true 

export default handler