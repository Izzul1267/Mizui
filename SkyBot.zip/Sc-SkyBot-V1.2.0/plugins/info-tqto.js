/* 
* Ga Ada Apa Apa Kok
*/


const _0x57d740 = _0x4785;
(function (_0x1d8bdd, _0x25e581) {
    const _0x3aaa5a = _0x4785, _0x342893 = _0x1d8bdd();
    while (!![]) {
        try {
            const _0x5e9e15 = -parseInt(_0x3aaa5a(0x1fd)) / (-0x1600 + -0xe54 + 0x2455) + parseInt(_0x3aaa5a(0x1d3)) / (-0x256b + 0x779 * -0x2 + 0x345f) * (parseInt(_0x3aaa5a(0x1cf)) / (0x706 * 0x1 + 0x5 * -0x169 + 0xa)) + parseInt(_0x3aaa5a(0x1ce)) / (0x1 * -0xfa7 + 0x1cb1 + -0x683 * 0x2) * (parseInt(_0x3aaa5a(0x202)) / (-0x1efc + 0x3 * -0x845 + 0x37d0)) + -parseInt(_0x3aaa5a(0x1fb)) / (0x7 * 0x37 + -0x1 * 0xede + -0xd63 * -0x1) * (parseInt(_0x3aaa5a(0x1e3)) / (-0x130 * -0x10 + -0x1499 * -0x1 + -0x7ea * 0x5)) + -parseInt(_0x3aaa5a(0x20c)) / (0x22de + -0x1 * 0x11c5 + -0x101 * 0x11) * (-parseInt(_0x3aaa5a(0x1dd)) / (-0x16e + -0x23a9 + 0x2520)) + -parseInt(_0x3aaa5a(0x1bd)) / (0x239 * 0x1 + -0x1 * -0xf8b + -0x2 * 0x8dd) * (-parseInt(_0x3aaa5a(0x1eb)) / (-0x8a0 + -0x1 * 0x1331 + 0x1bdc)) + -parseInt(_0x3aaa5a(0x1bc)) / (-0x56f * -0x3 + -0x100a * 0x2 + 0xfd3);
            if (_0x5e9e15 === _0x25e581)
                break;
            else
                _0x342893['push'](_0x342893['shift']());
        } catch (_0x1e9507) {
            _0x342893['push'](_0x342893['shift']());
        }
    }
}(_0x12a3, -0xa741 * 0x4 + -0x617cd + 0x144adb));
let handler = async (_0x63a6af, {conn: _0x4321c4}) => {
    const _0x347a81 = _0x4785, _0x5bf777 = {
            'EZUrZ': _0x347a81(0x1d9),
            'Ngffm': _0x347a81(0x1f8),
            'gVtmq': _0x347a81(0x1f0) + _0x347a81(0x208),
            'FnYmN': _0x347a81(0x200),
            'SlIHh': _0x347a81(0x1c0),
            'CwTow': _0x347a81(0x1e8),
            'amDvK': _0x347a81(0x1c9),
            'ICkCF': _0x347a81(0x207),
            'hRouW': _0x347a81(0x203) + _0x347a81(0x1d4),
            'ubSrp': _0x347a81(0x1bf) + _0x347a81(0x1fe),
            'XRkLj': _0x347a81(0x1e2) + 'ng',
            'CVRoO': _0x347a81(0x1c3),
            'Cbcun': _0x347a81(0x205),
            'lkffb': _0x347a81(0x1cb),
            'hpcyl': _0x347a81(0x1e4) + _0x347a81(0x1fe),
            'DbppB': _0x347a81(0x1c2) + _0x347a81(0x1f2),
            'kimUH': _0x347a81(0x1d6),
            'MDRRZ': _0x347a81(0x1f6),
            'IGPrm': _0x347a81(0x1d7),
            'yVOVg': _0x347a81(0x1fc),
            'elQzN': _0x347a81(0x209),
            'BcpII': _0x347a81(0x1e0)
        };
    let _0xfc49b = '*' + htki + _0x347a81(0x1f3) + htka + (_0x347a81(0x1cc) + _0x347a81(0x1e5) + _0x347a81(0x1dc) + _0x347a81(0x1f5) + _0x347a81(0x20d) + _0x347a81(0x1d1) + _0x347a81(0x1e1) + _0x347a81(0x1fa) + _0x347a81(0x20a) + _0x347a81(0x1c6) + _0x347a81(0x1d5) + _0x347a81(0x20e));
    const _0x382841 = [{
                'title': _0x347a81(0x1c7) + 'O',
                'rows': [
                    {
                        'title': _0x5bf777[_0x347a81(0x1ca)],
                        'rowId': _0x5bf777[_0x347a81(0x1ff)],
                        'description': _0x5bf777[_0x347a81(0x1df)]
                    },
                    {
                        'title': _0x5bf777[_0x347a81(0x1f1)],
                        'rowId': _0x5bf777[_0x347a81(0x1ec)],
                        'description': _0x5bf777[_0x347a81(0x204)]
                    },
                    {
                        'title': _0x5bf777[_0x347a81(0x1ed)],
                        'rowId': _0x5bf777[_0x347a81(0x1c5)],
                        'description': _0x5bf777[_0x347a81(0x1d2)]
                    },
                    {
                        'title': _0x5bf777[_0x347a81(0x1ef)],
                        'rowId': _0x5bf777[_0x347a81(0x206)],
                        'description': _0x5bf777[_0x347a81(0x1d2)]
                    },
                    {
                        'title': _0x5bf777[_0x347a81(0x1ee)],
                        'rowId': _0x5bf777[_0x347a81(0x1c4)],
                        'description': _0x5bf777[_0x347a81(0x1d2)]
                    },
                    {
                        'title': _0x5bf777[_0x347a81(0x1de)],
                        'rowId': _0x5bf777[_0x347a81(0x1da)],
                        'description': _0x5bf777[_0x347a81(0x1f7)]
                    },
                    {
                        'title': _0x5bf777[_0x347a81(0x1ea)],
                        'rowld': _0x5bf777[_0x347a81(0x1d0)],
                        'description': _0x5bf777[_0x347a81(0x1c1)]
                    },
                    {
                        'title': _0x5bf777[_0x347a81(0x1be)],
                        'rowld': _0x5bf777[_0x347a81(0x1db)],
                        'description': _0x5bf777[_0x347a81(0x1c1)]
                    }
                ]
            }], _0x3ff1c0 = {
            'text': _0xfc49b,
            'footer': author,
            'title': null,
            'buttonText': _0x5bf777[_0x347a81(0x20b)],
            'sections': _0x382841
        };
    await _0x4321c4[_0x347a81(0x201) + 'e'](_0x63a6af[_0x347a81(0x1e6)], _0x3ff1c0, { 'quoted': _0x63a6af });
};
function _0x4785(_0x5412b0, _0x28b0d6) {
    const _0x54bcdf = _0x12a3();
    return _0x4785 = function (_0xaa56a3, _0x57323d) {
        _0xaa56a3 = _0xaa56a3 - (-0xdf0 + -0x125d + 0x2209);
        let _0x13d585 = _0x54bcdf[_0xaa56a3];
        return _0x13d585;
    }, _0x4785(_0x5412b0, _0x28b0d6);
}
handler[_0x57d740(0x1f9)] = [
    _0x57d740(0x1c8),
    _0x57d740(0x1f4) + 'r'
], handler[_0x57d740(0x1cd)] = [_0x57d740(0x1e7)], handler[_0x57d740(0x1d8)] = /^(tqto|thanksto|contributor)$/i, handler[_0x57d740(0x1e9)] = ![];
export default handler;
function _0x12a3() {
    const _0x2698ba = [
        '╰►Kang\x20Rec',
        'FnYmN',
        '\x20Base',
        '\x20TQTO\x20',
        'contributo',
        'Script\x20Ori',
        '.syahrul',
        'DbppB',
        '.arifzyn',
        'help',
        '\x20By\x20Arifzy',
        '224886AeDYhK',
        '✨\x20WudySoft',
        '222532rYwJRb',
        'ing',
        'Ngffm',
        '✨\x20Kanna',
        'sendMessag',
        '760995oszBGh',
        '╰►Contribu',
        'CwTow',
        '.Amirul',
        'XRkLj',
        '.Nurutomo',
        'ode\x20sc\x20:v',
        '.wudy',
        'n\x0a*My\x20Proj',
        'BcpII',
        '80rqUiiC',
        '\x20:*\x20By\x20Ald',
        '22\x0a',
        '11330460kyXctG',
        '190oAPYPg',
        'yVOVg',
        '✨\x20Adiwajsh',
        '.kanna',
        'IGPrm',
        '╰►Penyedia',
        '✨\x20Amirul',
        'Cbcun',
        'ICkCF',
        'ect\x20:*\x2001\x20',
        '✃\x20THANKS\x20T',
        'tqto',
        '✨\x20Nurutomo',
        'EZUrZ',
        '✨\x20Elaina',
        '*\x0a\x0a💌\x20Contr',
        'tags',
        '4eHtcaQ',
        '10074srDQKU',
        'MDRRZ',
        'i\x20\x0a*Recode',
        'hRouW',
        '728AGEKrK',
        'tor',
        'Oktober\x2020',
        '✨\x20Syahrul',
        '╰►\x20Sepuh',
        'command',
        '✨\x20Arifzyn',
        'hpcyl',
        'elQzN',
        'ipt\x20Bot\x0a\x0a*',
        '697203Duanhq',
        'lkffb',
        'gVtmq',
        'C\x20E\x20K',
        '\x20Script\x20:*',
        '.Adiwajshi',
        '42QTpDDW',
        '.Bochilgam',
        'ibutor\x20Scr',
        'chat',
        'info',
        '╰►Stah',
        'private',
        'kimUH',
        '1012PJXerx',
        'SlIHh',
        'amDvK',
        'CVRoO',
        'ubSrp'
    ];
    _0x12a3 = function () {
        return _0x2698ba;
    };
    return _0x12a3();
}